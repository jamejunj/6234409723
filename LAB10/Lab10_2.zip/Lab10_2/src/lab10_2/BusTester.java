/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;
import java.util.ArrayList;
/**
 *
 * @author Lenovo
 */
public class BusTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Object> arr = new ArrayList<>();
        
        arr.add(new Hybrid(45,1.2E6,999,150,1));
        arr.add(new CNGBus(50,1E6,200,2));
        
        for(Object e : arr){
            System.out.println("ID: " + ((Bus)e).getID());
            if (e instanceof Hybrid){
                System.out.println("Emission Tier: " + ((Hybrid)e).getEmissionTier());
                System.out.println("Accel: " + ((Hybrid)e).getAccel());
            }
            if (e instanceof CNGBus){
                System.out.println("Emission Tier: " + ((CNGBus)e).getEmissionTier());
                System.out.println("Accel: " + ((CNGBus)e).getAccel());
            }
        }
    }
    
}
