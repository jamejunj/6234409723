/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author Lenovo
 */
public class Subject implements Evaluation {
    private String subjName;
    private int[] score;
    public Subject(String name,int[] s){
        subjName = name;
        score = s;
    }
    @Override
    public double evaluate(){
        int sum = 0;
        for(int e : score){
            sum+=e;
        }
        return sum;
    }
    @Override
    public char grade(double score){
        if (score>=70){
            return 'P';
        }else{
            return 'F';
        }
    }
    @Override
    public String toString(){
        return subjName;
    }
}
