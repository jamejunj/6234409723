/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author usci
 */
public class PurseTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Purse walletA = new Purse();
        Purse walletB = new Purse();
        walletA.addCoin("Penny");
        walletA.addCoin("Dime");
        walletA.addCoin("Quarter");
        walletB.addCoin("Penny");
        walletB.addCoin("Quarter");
        walletB.addCoin("Dime");
        System.out.println(walletA.sameCoins(walletB));
    }
    
}
