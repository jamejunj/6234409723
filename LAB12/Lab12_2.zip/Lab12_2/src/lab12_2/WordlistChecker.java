/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;

import java.io.*;
import java.util.*;
/**
 *
 * @author Lenovo
 */
public class WordlistChecker {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        // C:\Users\Lenovo\Desktop\myproj\Lab12_2\src\lab12_2\
        ArrayList<String> data = new ArrayList<>();
        try{
            Scanner in = new Scanner(new File("C:\\Users\\Lenovo\\Desktop\\myproj\\Lab12_2\\src\\lab12_2\\wordlist.txt"));
            String line;
            while (in.hasNextLine()){
                line = in.nextLine();
                data.add(line.trim());
            }
        }catch (IOException e){
            System.out.println(e);
        }
        System.out.print("Enter a sentence: ");
        String text = (new Scanner(System.in)).nextLine();
        Scanner t = new Scanner(text);
        System.out.println("Words not contained: ");
        boolean had = false;
        while(t.hasNext()){
            String check = (t.next()).trim();
            if (!data.contains(check)){
                System.out.println(check);
                had = true;
            }
        }
        if (!had){
            System.out.println("N/A");
        }
       
    }
    
}
