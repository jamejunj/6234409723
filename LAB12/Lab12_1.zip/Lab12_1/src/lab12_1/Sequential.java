/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.*;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Sequential{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        File f = new File("C:\\Users\\Lenovo\\Desktop\\myproj\\Lab12_1\\src\\lab12_1\\text.txt");
        java.io.PrintWriter out = new PrintWriter(f);
        Scanner input = new Scanner(System.in);
        String line;
        do{
            line = (input.nextLine());
            out.print(!line.equals("quit") ? line + "\n" : "");
        }while(!line.equals("quit"));
        out.close();
        System.out.println("Total characters : " + f.length());
        System.out.println("Total words : " + words(f));
        System.out.println("Total lines : " + line(f));
    }
    
    public static int words(File file) throws IOException{
        int w = 0;
        Scanner in = new Scanner(file);
        while (in.hasNextLine()){
            String line = in.nextLine();      
            w++;
            for (int i=0;i<line.length();i++){
                if (line.charAt(i)==' '){
                    w++;
                }
            }
        }
        in.close();
        return w;
    }
    
    public static int line(File file) throws IOException{
        int l = 0;
        Scanner in = new Scanner(file);
        while (in.hasNextLine()){
            l++;
            in.nextLine();
        }
        in.close();
        return l;
    }
}
