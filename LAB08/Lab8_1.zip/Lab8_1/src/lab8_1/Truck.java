/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Lenovo
 */
public class Truck extends Car {
    private double maxWeigth,weight; // ton
    public Truck(double gas,double efficiency,double maxWeigth, double weight){
        super(gas,efficiency);
        this.maxWeigth = maxWeigth;
        this.weight = weight>maxWeigth ? maxWeigth : weight;
    }
    
    @Override
    public void drive(double distance){
        double loss = distance/(1.0*getEfficiency());
        if(weight>20){
            loss*=1.3;
        }else if (weight>10){
            loss*=1.2;
        }else if (weight>=1){
            loss*=1.1;
        }
        if (getGas() - loss < 0){
            System.out.println("You cannot drive too far, please add gas");
        }else{
            addGas(-loss);
        }
    }
}
