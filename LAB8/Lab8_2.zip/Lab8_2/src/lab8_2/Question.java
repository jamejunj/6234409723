/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author Lenovo
 */
public class Question {
    private String text,answer;
    public Question(){
        
    }
    public Question(String t){
        text = t;
    }
    public String getAnswer(){
        return answer;
    }
    public void setAnswer(String ans){ answer = ans; }
    public void setText(String t){ text = t; }
    public boolean checkAnswer(String response){
        return response.equals(answer);
    }
    public void display(){
        System.out.println(text);
    }
}
