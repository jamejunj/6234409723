/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;
import java.util.ArrayList;
/**
 *
 * @author Lenovo
 */
public class ChoiceQuestion extends Question{
    ArrayList<String> choices = new ArrayList<>();
    public ChoiceQuestion(String text){
        super(text);
    }
    
    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if (correct){
            setAnswer(choice);
        }
    }
    @Override
    public void display(){
        super.display();
        int i=0;
        for(String element : choices){
            System.out.println(++i+": "+element);
        }
    }
    @Override
    public boolean checkAnswer(String response){
        return choices.get(Integer.parseInt(response)-1)==getAnswer();
    }
}
