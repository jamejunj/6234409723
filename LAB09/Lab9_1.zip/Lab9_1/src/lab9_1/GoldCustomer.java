/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

/**
 *
 * @author Lenovo
 */
public class GoldCustomer extends Customer {
    private double discount;
    public GoldCustomer(String n,String t,double d){
        super(n,t);
        discount = d;
    }
    public double getDiscount(){
        return discount;
    }
    @Override
    public String toString(){
        return super.toString() + " discount : " + discount;
    }
}
