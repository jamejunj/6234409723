/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

/**
 *
 * @author Lenovo
 */
public class Pizza {
    private String name;
    private double price;
    public Pizza(){
    
    }
    public Pizza(String n,double p){
        name = n;
        price = p;
    }
    public double getPrice(){
        return price;
    }
    @Override
    public String toString(){
        return name + " price : " + price;
    }
}
