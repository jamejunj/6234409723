/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

import java.util.ArrayList;
/**
 *
 * @author Lenovo
 */
public class Order {
    public static int cntOrder = 0; // auto generate id of order
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
    public Order(Customer cus){
        c = cus;
        id = ++cntOrder;
    }
    public void addPizza(Pizza p){
        this.p.add(p);
    }
    
    public String getOrderDetail(){
        String text = "";
        double sum=0;
        int cnt=0;
        text += "Order id : "+id+"\n";
        text += c+"\n";
        for(Pizza e : p){
            text += e +"\n";
            sum+=e.getPrice();
            cnt++;
        }
        text += "Total pieces : " +cnt+"\n";
        text += "Total cost : " +sum;
        return text;
    }
    
    public double calculatePayment(){
        double sum=0;
        for(Pizza e : p){
            sum+=e.getPrice();
        }
        sum-= sum*(c.getDiscount()/100.0);
        return sum;
    }
    
}
