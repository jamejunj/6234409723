/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

/**
 *
 * @author Lenovo
 */
public class PizzaSpecial extends Pizza {
    private String special;
    public PizzaSpecial(String n, double p, String s){
        super(n,p);
        special = s;
    }
    @Override
    public String toString(){
        return super.toString() + " special : " + special;
    }
}
