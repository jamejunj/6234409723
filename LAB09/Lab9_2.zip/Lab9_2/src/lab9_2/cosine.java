/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Lenovo
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lenovo
 */
public class cosine extends Taylor{ 
    public cosine(int k, double x){
        super(k,x);
    }
    public double getApprox(){
        double apx = 0;
        for(int i=0;i<super.getIter();i++){
            apx += Math.pow(-1,i)*Math.pow(super.getValue(),2*i)/(1.0*super.factorial(2*i));
        }
        return apx;
    }
    
    public void printValue(){
        System.out.println("Value from Math.cos() is " + Math.cos(super.getValue()));
        System.out.println("Approximate value is " + getApprox());
        //System.out.println(String.format("%% Error : %.15f",100*Math.abs(Math.cos(super.getValue()) - getApprox())/Math.cos(super.getValue())));
    }
}
