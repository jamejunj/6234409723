/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Lenovo
 */
public class sine extends Taylor{
    public sine(int k, double x){
        super(k,x);
    }
        @Override
    public double getApprox(){
        double apx = 0;
        for(int i=0;i<super.getIter();i++){
            apx += Math.pow(-1,i)*Math.pow(super.getValue(),2*i+1)/(1.0*super.factorial(2*i+1));
        }
        return apx;
    }
    
    public void printValue(){
        System.out.println("Value from Math.sin() is " + Math.sin(super.getValue()));
        System.out.println("Approximate value is " + getApprox());
        //System.out.println(String.format("%% Error : %.15f",100*Math.abs(Math.sin(super.getValue()) - getApprox())/Math.sin(super.getValue())));
    }
}
