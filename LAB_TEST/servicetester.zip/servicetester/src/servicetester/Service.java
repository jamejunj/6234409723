package servicetester;
import java.util.ArrayList;
public abstract class Service {
    private String name;  //ชื่อผู้ให้บริการ
    private ArrayList<Product> prodL;   //ลิสต์ที่เก็บสินค้าหรือบริการที่ขาย
    private ArrayList<Product> buyL;    //ลิสต์ที่เก็บสินค้าหรือบริการที่ลูกค้ามาซื้อ
    public Service(String n) {
        name = n;
        prodL = new ArrayList<Product>(); 
        buyL = new ArrayList<Product>();
    }
    public void addProduct(Product d) { //เพิ่มสินค้าลงในลิสต์สินค้าของร้าน
        prodL.add(d);
    }    
    public void buyProduct(Product d) { //ลิสต์ที่เก็บสินค้าหรือบริการที่ลูกค้ามาซื้อ
        buyL.add(d);
    }
    public void clearBuyList() { //เคลียร์ลิสต์ที่เก็บสินค้าที่ลูกค้าซื้อให้ว่างเพื่อรอรับลูกค้าใหม่
        buyL.clear();
    }
    //คิดเงินค่าสินค้าหรือบริการ subclass ต้องนำไป override
    public abstract double charge(int type, ArrayList<Product> buy);
    public ArrayList<Product> getBuyList() {    //เอาลิสต์สินค้าที่ลูกค้าซื้อไปใช้งาน
        return buyL;
    }
    public String toString() {  // แสดงค่าตัวแปร
        String s = getClass().getName() + "\n" + name + "\n";
        for (Product p : prodL) {
            s += p.getName() + " " + p.getPrice() + "\n";
        }
        return s;
    }
}
