package servicetester;
import java.util.ArrayList;
public class ServiceTester {
    public static void main(String[] args) {
        //สร้างอาร์เรย์ลิสต์เพื่อเก็บ object ของร้านค้าประเภทต่าง ๆ ทีสมัครมาเป็นร้านขายของในระบบของเรา
        ArrayList<Service> service = new ArrayList<Service>();
        //ทดลองสร้างโรงเรียนกวดวิชาที่ให้บริการสอนพิเศษ
        service.add(new Tutor("My Demand"));
        //สร้าง object รายชื่อวิชาที่ให้บริการ
        Product c1 = new Product("Phys_4_2", 2000, "Physics M.4 Semester2");
        Product c2 = new Product("Chem_4_2", 2000, "Chemistry M.4 Semester2");
        Product c3 = new Product("Math_4_2", 2000, "Mathematics M.4 Semester2");        
        //นำรายชื่อรายวิชาใส่เข้าไปในลิสต์ของสิ่งที่โรงเรียนให้บริการได้
        service.get(0).addProduct(c1);
        service.get(0).addProduct(c2);
        service.get(0).addProduct(c3);
        //สั่งพิมพ์ดูค่าข้อมูลต่าง ๆ ของโรงเรียน
        System.out.println(service.get(0).toString());
        //จำลองสถานการณ์การที่มีคนมาซื้อบริการจากทางโรงเรียน
        //สมมติว่า มีนักเรียนมาซื้อคอร์สเรียน 2 คอร์ส 
        service.get(0).buyProduct(c1);
        service.get(0).buyProduct(c2);
        //คิดเงินและพิมพ์แสดงเป็นผลลัพธ์
        System.out.println("Total cost = " + service.get(0).charge(1, service.get(0).getBuyList()));
        //เคลียร์ให้ลิสต์ที่เก็บข้อมูลที่ลูกค้ามาซื้อคอร์สทิ้งไป เพื่อรอรับการมาซื้อคอร์สของนักเรียนคนถัดไป
        service.get(0).clearBuyList();
        //-------------------- จบส่วนทดสอบของคลาสที่ครูสร้างให้เท่านี้
   
        //ด้านล่างนี้ครูเตรียมคำสั่งเผื่อไว้ให้นิสิตเอาไปปรับใช้เพื่อทดสอบคลาสของตัวเองได้แล้วแต่ว่านิสิตเพิ่มตัวแปรกี่ตัว
        service.add(new BookStore("SEE-IT Book Center",5)); // ร้านหนังสือ ซี-อิท บุ๊คเซ็นเตอร์ มีส่วนลด 5% สำหรับหนังสือทุกรายการ
        Product f1 = new Product("Basic Python Prog", 250, "Learn how to program basic");
        Product f2 = new Product("Basic Java Prog", 300, "Learn how to program java basic");
        Product f3 = new Product("Basic PHP Prog", 990, "Learn how to PHP basic");
        service.get(1).addProduct(f1);
        service.get(1).addProduct(f2);
        service.get(1).addProduct(f3);  
        //ผลที่ได้จาก toString อย่าลืมว่านิสิตต้องแสดงตัวแปรที่เพิ่มใหม่ในคลาสที่นิสิตสร้างด้วย
        System.out.println(service.get(1).toString()); // เพิ่มไปว่าร้านให้ส่วนลดกี่ %
        //จำลองว่ามีลูกค้ามาซื้อสินค้าหรือบริการจากระยบของเรา
        service.get(1).buyProduct(f1);
        service.get(1).buyProduct(f2);
        System.out.println("Total cost = " + service.get(1).charge(0, service.get(1).getBuyList()));
       
        service.get(1).clearBuyList();
        /* ล่างสุดนี้ ขอให้นิสิตเพิ่มคำสั่งเพื่อทดสอบการเรียกใช้เมท็อดใหม่ที่สร้างขึ้น 
โดยเรียกใช้ set, get method สำหรับตัวแปร instance variable ที่เพิ่มขึ้นมาในคลาสที่นิสิตสร้างด้วย
        */
         ((BookStore)service.get(1)).setDiscount(10);
         System.out.println("Shop discount = " + ((BookStore)service.get(1)).getDiscount());
    }
}
