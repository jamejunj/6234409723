package servicetester;
import java.util.ArrayList;
public class Tutor extends Service{
    //สมมติว่า ระบบของเรากำหนดให้โรงเรียนกวดวิชา ให้บริการได้ 3 ช่องทาง
    //และนักเรียนที่สมัครเรียนเกินกว่า 1 คอร์ส จะได้รับส่วนลดแตกต่างกันแล้วแต่ช่องทาง
    //type1 = study live at school
    //type2 = study video at school
    //type3 = study video online at home
    public Tutor(String n) {
        super(n);
    }
    public double charge(int type, ArrayList<Product> buy) {
        //เพื่อให้ง่าย ขอสมมติว่า เวลานักเรียนสมัครจะเลือกช่องทางเดียวสำหรับทุกวิชาที่เลือก
        double sum = 0;
        System.out.println("Selected courses : ");
        for (Product p:buy) {
            System.out.println(p.getName());
            sum += p.getPrice();
        }  //คิดเงินและนำมาให้ส่วนลดกับนักเรียนถ้าลงเรียนมากกว่า 1 คอร์ส
        if (type == 1 && buy.size() > 1)
            return sum = sum * 0.95;
        else if (type == 2 && buy.size() > 1)
            return sum = sum * 0.90;
        else if (type == 3 && buy.size() > 1)
            return sum = sum * 0.80;
        else
            return sum;
    }
}
