package servicetester;
public class Product {
    private String name;    //ชื่อสินค้า
    private double price;   //ราคา
    private String detail;  //รายละเอียด
    public Product (String n, double p, String det) {
        name = n;
        price = p;
        detail = det;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
    public String getDetail() {
        return detail;
    }
}
