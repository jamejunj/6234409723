/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicetester;

import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class BookStore extends Service{
    // กำหนดให้เรามี type สองแบบคือ 0 ไม่เป็นสมาชิก 1 เป็นสมาชิก  และ 2 เป็นนักเรียน นิสิต นักศึกษา
    // สมาชิกจะได้รับส่วนลด 15% นักเรียนนิสิตนักศึกษาจะได้รับส่วนลด 20%
     double sum = 0;
     private double ShopDiscount;
     public BookStore(String n,double dc) {
        super(n);
        ShopDiscount = dc; // กำหนดส่วนลดสำหรับหนังสือทุกรายการ
    }
     @Override
    public double charge(int type,ArrayList<Product> buy){
         for (Product p:buy) {
            System.out.println(p.getName());
            sum += p.getPrice();
        }
         if (type==1){
             sum*=0.85;
         }else if (type==2){
             sum*=0.80;
         }
         sum *= (100-5)/100.0;
         return sum;
    }
    @Override
    public String toString() {  // แสดงค่าตัวแปร
        return super.toString() + "Shop discount = " + ShopDiscount +"%\n";
    }
    
   public double getDiscount(){
       return ShopDiscount;
   }
   
   public void setDiscount(double d){
       ShopDiscount = d;
   }

}
