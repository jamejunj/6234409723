/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airpurifier;

/**
 *
 * @author Lenovo
 */
public class VeryGreatCapacityFilter extends Filter{
    private static final int START_CAPACITY = 30000;
    private  double REDUCE;
    public VeryGreatCapacityFilter(double reduce) {        
        currentCapacity = START_CAPACITY;
        REDUCE = reduce; // ความสามารถในการเปลี่ยนฝุ่นให้สลายเป็นสสารมืด
    }
    // ไส้กรองนี้จะสามารถสลายฝุ่นที่รับเข้ามาได้ โดยการเปลี่ยนไปเป็นสสารมืดในอวกาศ ไม่เกิดมลภาวะต่อสิ่งแวดล้อม
    @Override
    public void filter(int airVolumnInLiter) {
        this.currentCapacity = Math.max(0, currentCapacity - (int)(airVolumnInLiter*(1-REDUCE)));
    }
    
    public void setReduce(double reduce){
         REDUCE = reduce;
    }
    
    public double getReduce(){
         return REDUCE;
    }
}
