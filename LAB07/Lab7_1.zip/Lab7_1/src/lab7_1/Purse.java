/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;
import java.util.*;  
/**
 *
 * @author usci
 */
public class Purse {
    public ArrayList<String> coin = new ArrayList<>();
    public void addCoin(String coinName){
        coin.add(coinName);
    }
    
    /*@Overide*/  
    public String toString(){
        return "Purse" + coin.toString();
    }
    
    /*@Overide*/ 
    public ArrayList<String> reverse(){
        ArrayList<String> temp = new ArrayList<>();
        for(int i=0;i<coin.size();i++){
            temp.add("");
        }
        int j=0;
        for(int i=coin.size()-1;i>=0;i--){
            temp.set(i, coin.get(j++));
        }
        return temp;
    }
    
    public void transfer(Purse other){
        for(int i=0;i<coin.size();i++){
            other.coin.add(coin.get(i));
        }
        coin.clear();
    }
    
    public boolean sameContents(Purse other){
        if (coin.size()!=other.coin.size()){
            return false;
        }
        for(int i=0;i<coin.size();i++){
            if (!coin.get(i).equals(other.coin.get(i))){
                return false;
            }
        }
        return true;
    }
    
    public boolean sameCoins(Purse other){
        int[] type = {0,0,0,0};
        int[] other_type = {0,0,0,0};
        if (coin.size()!=other.coin.size()){
            return false;
        }
        for(int i=0;i<coin.size();i++){
            String face = this.coin.get(i);
            switch(face){
                case "Penny":
                    type[0]+=1;
                    break;
                case "Nickel":
                    type[1]+=1;
                    break;
                case "Dime":
                    type[2]+=1;
                    break;
                case "Quarter":
                    type[3]+=1;
                    break;
            }     
        }
        for(int i=0;i<coin.size();i++){
            String face = other.coin.get(i);
            switch(face){
                case "Penny":
                    other_type[0]+=1;
                    break;
                case "Nickel":
                    other_type[1]+=1;
                    break;
                case "Dime":
                    other_type[2]+=1;
                    break;
                case "Quarter":
                    other_type[3]+=1;
                    break;
            }     
        }
        if (Arrays.equals(type,other_type)){
            return true;
        }else{
            return false;
        }
    }
    
}
