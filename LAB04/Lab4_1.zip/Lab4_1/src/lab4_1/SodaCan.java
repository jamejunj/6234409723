/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
public class SodaCan{
    private int diameter;
    private int height;
    public SodaCan(int h, int d){
        this.diameter = d;
        this.height = h;
    }

    public double getVolume(){
        return Math.PI*Math.pow(diameter/2.0,2)*height;
    }

    public double getSurfaceArea(){
        return 2*Math.PI*(diameter/2.0)*height + 2*Math.PI*Math.pow(diameter/2.0,2);
    }
}
