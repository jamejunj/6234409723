/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

/**
 *
 * @author usci
 */
import java.util.Scanner;
public class SodaTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter height: ");
        int high = Integer.parseInt(in.nextLine());
        System.out.print("Enter diameter: ");
        int diam = Integer.parseInt(in.nextLine());
        SodaCan x = new SodaCan(high,diam);
        System.out.println(String.format("Volume: %.2f",x.getVolume()));
        System.out.println(String.format("Surface area: %.2f" , x.getSurfaceArea()));
    }
    
}
