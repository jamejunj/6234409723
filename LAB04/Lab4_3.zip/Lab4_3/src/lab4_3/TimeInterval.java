/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author usci
 */
public class TimeInterval {
    private int min1,min2;
    
    public TimeInterval(int start, int end){
        int min1 = start%100;
        int hour1 = start/100;
        int min2 = end%100;
        int hour2 = end/100;
        this.min1 = min1+hour1*60;
        this.min2 = min2+hour2*60;
    }
    
    public int getHours(){
        return (min2-min1)/60;
    }
    
    public int getMinutes(){
        return (min2-min1)%60;
    }
}
