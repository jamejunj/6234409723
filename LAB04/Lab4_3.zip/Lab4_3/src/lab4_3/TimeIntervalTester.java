/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author usci
 */
import java.util.Scanner;

public class TimeIntervalTester {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = Integer.parseInt(in.nextLine());
        System.out.print("Enter end time: ");
        int end = Integer.parseInt(in.nextLine());
        TimeInterval timer = new TimeInterval(start,end);
        System.out.println(timer.getHours()+" hours "+timer.getMinutes()+" minutes");
    }
    
}
