package com.example.eastersunday;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Results extends AppCompatActivity {

    String year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        year = getIntent().getExtras().getString("Year");
        EasterSunday easter = new EasterSunday(year);

        TextView resultInDate = findViewById(R.id.output);
        String resultDate = easter.getEasterDay();
        resultInDate.setText(resultDate);
    }
}
