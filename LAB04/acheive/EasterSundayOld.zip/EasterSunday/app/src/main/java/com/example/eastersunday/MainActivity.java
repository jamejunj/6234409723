package com.example.eastersunday;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    EditText year;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        year = (EditText) findViewById(R.id.inputYear);
        Button submit = (Button) findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String y = year.getText().toString();
                if (y.length()!=0) {
                    Intent intent = new Intent(getApplicationContext(), Results.class);
                    intent.putExtra("Year", y);
                    startActivity(intent);
                }else{
                    Toast toast=Toast.makeText(getApplicationContext(),"Please enter year!",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }
}