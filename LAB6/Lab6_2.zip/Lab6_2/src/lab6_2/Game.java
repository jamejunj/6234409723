/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author usci
 */
public class Game {
    int playerScore = 0;
    int computerScore = 0;
    Scanner in = new Scanner(System.in);
    Random gen = new Random();
    private static boolean isInteger(String s){
        try{
            Integer.parseInt(s);
        }catch(NumberFormatException e){
            return false;
        }catch(NullPointerException e){
            return false;
        }
        return true;
    }
    
    public void play(){
         int s = 0;
         while (Math.abs(playerScore - computerScore)!=2){
             String input;
             do{
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
                input = in.nextLine();
             }while (!isInteger(input) || Integer.parseInt(input)<0 || Integer.parseInt(input)>2);
             int Player = Integer.parseInt(input);
             String[] item = {"ROCK","PAPER","SCISSORS"};
             System.out.println("You enter: "+item[Player]);
             int Computer = gen.nextInt(3);
             System.out.println("Computer: "+item[Computer]);
             String[] statusText = {"It's a tie.","You lose!","You win!"};
             if(Player==Computer){
                 s = 0;
             }else if (Player==0 && Computer==1 || Player==1 && Computer==2 || Player==2 && Computer==0){
                 s = 1;
                 computerScore+=1;
             }else if (Player==0 && Computer==2 || Player==1 && Computer==0 || Player==2 && Computer==1){
                 s = 2;
                 playerScore+=1;
             }
             System.out.println(statusText[s]);
         }
         String[] statusText = {"","Too bad! You lose.","Congrats! You win."};
         System.out.println(statusText[s]);
         System.out.println("User Score: "+playerScore);
         System.out.println("Computer Score: "+computerScore);
    }
}