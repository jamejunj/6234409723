/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

import java.util.Random;
/**
 *
 * @author usci
 */
public class CityGrid {
    private int xCoor;
    private int yCoor;
    public final int gridSize;
    public CityGrid(int s){
        gridSize = s;
        xCoor = s/2;
        yCoor = s/2;
    }
    
    public void walk(){
        Random gen = new Random();
        int w = gen.nextInt(4);
        switch (w){
            case 0:
                xCoor++;
                break;
            case 1:
                xCoor--;
                break;
            case 2:
                    yCoor++;
                break;
            case 3:
                yCoor--;
                break;
        }
    }
    
    public boolean isInCity(){
        if (xCoor>=0 && yCoor>=0 && xCoor<=gridSize && yCoor<=gridSize){
            return true;
        }else{
            return false;
        }
    }
    
    public void reset(){
        xCoor = gridSize/2;
        yCoor = gridSize/2;
    }
}
