/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

/**
 *
 * @author usci
 */
public class CityGridTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CityGrid jame = new CityGrid(10);
        int sumWalk = 0;
        int max = 0;
        for(int t=0;t<10000;t++){
            for(int i=0;i<1000;i++){
                jame.walk();
                if (!jame.isInCity()){
                    sumWalk+=i;
                    max = (i>max ? i : max);
                    jame.reset();
                    break;
                }
            }
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n",sumWalk/10000.0);
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+max);
    }
    
}
