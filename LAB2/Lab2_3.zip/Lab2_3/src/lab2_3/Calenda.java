/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.GregorianCalendar;
import java.util.Calendar;

/**
 *
 * @author usci
 */
public class Calenda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.FEBRUARY, 24);
        cal.add(Calendar.DAY_OF_MONTH,100);
        myBirthday.add(Calendar.DAY_OF_MONTH,10000);
        System.out.printf("%d %d %d %d\n",cal.get(Calendar.DAY_OF_WEEK),cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.MONTH),cal.get(Calendar.YEAR));
        System.out.printf("%d %d %d %d\n",myBirthday.get(Calendar.DAY_OF_WEEK),myBirthday.get(Calendar.DAY_OF_MONTH),myBirthday.get(Calendar.MONTH),myBirthday.get(Calendar.YEAR));
    }
    
}
