/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author usci
 */
public class CannonBall {
    private double initV;
    private double simS;
    private double simT = 0;
    public static final double g = 9.81;
    
    public CannonBall(double v){
        initV = v;
    }
    
    public void simulatedFlight(){
        double v = initV;
        int sec = 0;
        while(v>0){
            for(int i=0;i<100;i++){
                simT+=0.01;
                simS+=v*0.01;
                v-=g*0.01;
                if (v<0){
                    break;
                }
            }
            if (v<0){
                System.out.println(String.format("Final distance: %.3f Total time: %.2f",getSimulatedDistance(),getSimulatedTime()));
                break;
            }
            sec+=1;
            System.out.println(String.format("Distance on %d sec: %.3f",sec,simS));
        }
    }
    
    public double calculusFlight(double t){
        System.out.print("Distance from calculus equation: ");
        return Math.round((-0.5*g*Math.pow(t,2) + initV*t)*1000.0)/1000.0;
    }
    
    public double getSimulatedTime(){
        return simT;
    }
    
    public double getSimulatedDistance(){
        return simS;
    }
}