/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class SelfCheckOut implements SimpleQueue{
    ArrayList<Product> p = new ArrayList<>();
    double sum;
    @Override
    public void enqueue(Object o){
        p.add((Product)o);
        System.out.println(((Product)o).getName() + "is added in queue");
    }
    @Override
    public void dequeue(){
        sum+=p.get(0).getPrice();
        p.remove(0);
    }
    
    public double getAmount(){
        return sum;
    }
}
