package lab11_1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
/**
 *
 * @author Lenovo
 */
public class MusicBox implements SimpleQueue {
    ArrayList<String> q = new ArrayList<>();
    @Override
    public void enqueue(Object o){
        q.add((String)o);
        System.out.println((String)o + " is added in queue");
    }
    @Override
    public void dequeue(){
        System.out.println("Now playing " + q.get(0));
        q.remove(0);
    }
}
